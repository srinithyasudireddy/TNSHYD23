package tns6;

public class G {
	protected void display() {
		System.out.println("tns");
	}

}
