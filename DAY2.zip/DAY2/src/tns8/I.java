package tns8;

public class I {
	public void display() {
	System.out.println("tns");


	}

}
