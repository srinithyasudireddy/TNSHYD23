package tns7;
import tns6.*;
public class H extends G {
	public static void main(String[] args) {
		H g1 = new H();
		g1.display();
		}
	}
