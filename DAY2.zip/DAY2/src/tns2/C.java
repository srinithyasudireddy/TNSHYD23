package tns2;

public class C {
	private static void main(String[] args) {
		C obj=new C();
		obj.display();
	}

}
