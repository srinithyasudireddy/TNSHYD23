package day;

public class C {
	int b=10;
	int display() {
		return 10;
		}
	static int c=5;
	static void display1() {
		System.out.println(10);
		}
	public static void main(String[] args) {
		int a=20;
		System.out.println(a);
		C c1 = new C();
		System.out.println(c1.b);
		c1.display();
		System.out.println(C.c);
		C.display1();
	}
}
